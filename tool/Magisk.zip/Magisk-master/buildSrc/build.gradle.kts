plugins {
    `kotlin-dsl`
}
repositories {
    jcenter()
}

gradlePlugin {
    plugins {
        register("MagiskPlugin") {
            id = "MagiskPlugin"
            implementationClass = "MagiskPlugin"
        }
    }
}
